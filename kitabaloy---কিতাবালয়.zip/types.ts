
export interface Book {
  id: string;
  name: string;
  library: string;
  price: number;
  salesCount: number;
  addedAt: number;
}

export interface Transaction {
  id: string;
  date: number;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  description: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  totalPurchase: number;
}

export type TabType = 'dashboard' | 'inventory' | 'finance' | 'customers' | 'analytics';

export interface FinanceSummary {
  daily: number;
  weekly: number;
  monthly: number;
}
