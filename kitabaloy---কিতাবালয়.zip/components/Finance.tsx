
import React, { useState, useMemo } from 'react';
import { Plus, ArrowUpCircle, ArrowDownCircle, History, Filter } from 'lucide-react';
import { Transaction } from '../types';

interface FinanceProps {
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
}

export const Finance: React.FC<FinanceProps> = ({ transactions, setTransactions }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTrans, setNewTrans] = useState({ amount: '', type: 'income' as 'income' | 'expense', category: '', description: '' });

  const stats = useMemo(() => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay()).getTime();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

    const getPeriodSums = (startTime: number) => {
      const filtered = transactions.filter(t => t.date >= startTime);
      const income = filtered.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
      const expense = filtered.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
      return { income, expense };
    };

    return {
      daily: getPeriodSums(startOfDay),
      weekly: getPeriodSums(startOfWeek),
      monthly: getPeriodSums(startOfMonth)
    };
  }, [transactions]);

  const addTransaction = () => {
    if (!newTrans.amount || !newTrans.category) return;
    const trans: Transaction = {
      id: Date.now().toString(),
      date: Date.now(),
      amount: parseFloat(newTrans.amount),
      type: newTrans.type,
      category: newTrans.category,
      description: newTrans.description,
    };
    setTransactions(prev => [trans, ...prev]);
    setNewTrans({ amount: '', type: 'income', category: '', description: '' });
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      {/* Finance Tabs for Periods */}
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-sm font-bold text-slate-500 mb-4 flex items-center">
            <History size={16} className="mr-2" /> হিসাব সারসংক্ষেপ
          </h3>
          <div className="space-y-4">
            {/* Daily */}
            <div className="flex items-center justify-between border-b border-slate-50 pb-3">
              <span className="text-sm text-slate-600 font-medium">আজকের</span>
              <div className="text-right">
                <p className="text-emerald-600 font-bold text-sm">+৳{stats.daily.income}</p>
                <p className="text-rose-500 font-bold text-sm">-৳{stats.daily.expense}</p>
              </div>
            </div>
            {/* Weekly */}
            <div className="flex items-center justify-between border-b border-slate-50 pb-3">
              <span className="text-sm text-slate-600 font-medium">এই সপ্তাহের</span>
              <div className="text-right">
                <p className="text-emerald-600 font-bold text-sm">+৳{stats.weekly.income}</p>
                <p className="text-rose-500 font-bold text-sm">-৳{stats.weekly.expense}</p>
              </div>
            </div>
            {/* Monthly */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-600 font-medium">এই মাসের</span>
              <div className="text-right">
                <p className="text-emerald-600 font-bold text-sm">+৳{stats.monthly.income}</p>
                <p className="text-rose-500 font-bold text-sm">-৳{stats.monthly.expense}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Transaction Button */}
      <button 
        onClick={() => setShowAddForm(true)}
        className="w-full bg-indigo-600 text-white p-4 rounded-xl flex items-center justify-center space-x-2 font-bold shadow-lg"
      >
        <Plus size={20} />
        <span>নতুন লেনদেন যোগ করুন</span>
      </button>

      {/* Transactions List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-slate-700">সাম্প্রতিক লেনদেন</h3>
          <Filter size={18} className="text-slate-400" />
        </div>
        {transactions.length === 0 ? (
          <div className="text-center py-10 text-slate-400">কোনো লেনদেন পাওয়া যায়নি</div>
        ) : (
          transactions.map(t => (
            <div key={t.id} className="bg-white p-4 rounded-xl border border-slate-100 flex items-center justify-between shadow-sm">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-full ${t.type === 'income' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-500'}`}>
                  {t.type === 'income' ? <ArrowUpCircle size={24} /> : <ArrowDownCircle size={24} />}
                </div>
                <div>
                  <p className="font-bold text-slate-800 text-sm">{t.category}</p>
                  <p className="text-xs text-slate-400">{new Date(t.date).toLocaleDateString('bn-BD')}</p>
                </div>
              </div>
              <p className={`font-bold ${t.type === 'income' ? 'text-emerald-600' : 'text-rose-500'}`}>
                {t.type === 'income' ? '+' : '-'} ৳{t.amount}
              </p>
            </div>
          ))
        )}
      </div>

      {/* Add Transaction Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl p-6 shadow-2xl animate-in slide-in-from-bottom duration-300">
            <h2 className="text-xl font-bold mb-4">নতুন লেনদেন</h2>
            <div className="space-y-4">
              <div className="flex p-1 bg-slate-100 rounded-lg">
                <button 
                  className={`flex-1 py-2 rounded-md font-bold text-sm ${newTrans.type === 'income' ? 'bg-white shadow text-emerald-600' : 'text-slate-500'}`}
                  onClick={() => setNewTrans({...newTrans, type: 'income'})}
                >আয়</button>
                <button 
                  className={`flex-1 py-2 rounded-md font-bold text-sm ${newTrans.type === 'expense' ? 'bg-white shadow text-rose-500' : 'text-slate-500'}`}
                  onClick={() => setNewTrans({...newTrans, type: 'expense'})}
                >ব্যয়</button>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">পরিমাণ (৳)</label>
                <input 
                  type="number" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newTrans.amount}
                  onChange={e => setNewTrans({...newTrans, amount: e.target.value})}
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">ধরণ/ক্যাটাগরি</label>
                <input 
                  type="text" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newTrans.category}
                  onChange={e => setNewTrans({...newTrans, category: e.target.value})}
                  placeholder="যেমন: অফিস ভাড়া, নাস্তা খরচ"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">বিবরণ (ঐচ্ছিক)</label>
                <textarea 
                  className="w-full p-3 border border-slate-200 rounded-lg h-20"
                  value={newTrans.description}
                  onChange={e => setNewTrans({...newTrans, description: e.target.value})}
                  placeholder="..."
                />
              </div>
              <div className="flex space-x-3 pt-2">
                <button onClick={() => setShowAddForm(false)} className="flex-1 py-3 border border-slate-200 text-slate-600 rounded-lg font-bold">বাতিল</button>
                <button onClick={addTransaction} className="flex-1 py-3 bg-indigo-600 text-white rounded-lg font-bold">নিশ্চিত করুন</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
