
import React, { useState, useMemo } from 'react';
import { Search, Plus, Trash2, Library, Tag, ShoppingCart } from 'lucide-react';
import { Book, Transaction } from '../types';

interface InventoryProps {
  books: Book[];
  setBooks: React.Dispatch<React.SetStateAction<Book[]>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
}

export const Inventory: React.FC<InventoryProps> = ({ books, setBooks, transactions, setTransactions }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newBook, setNewBook] = useState({ name: '', library: '', price: '' });

  const filteredBooks = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return books.filter(book => 
      book.name.toLowerCase().includes(term) || 
      book.library.toLowerCase().includes(term) ||
      book.price.toString().includes(term)
    );
  }, [books, searchTerm]);

  const addBook = () => {
    if (!newBook.name || !newBook.price) return;
    const book: Book = {
      id: Date.now().toString(),
      name: newBook.name,
      library: newBook.library || 'অজানা লাইব্রেরি',
      price: parseFloat(newBook.price),
      salesCount: 0,
      addedAt: Date.now(),
    };
    setBooks(prev => [book, ...prev]);
    setNewBook({ name: '', library: '', price: '' });
    setShowAddForm(false);
  };

  const sellBook = (id: string) => {
    const bookToSell = books.find(b => b.id === id);
    if (!bookToSell) return;

    // Increment sales count
    setBooks(prev => prev.map(b => b.id === id ? { ...b, salesCount: b.salesCount + 1 } : b));
    
    // Add income transaction
    const trans: Transaction = {
      id: `sale-${Date.now()}`,
      date: Date.now(),
      amount: bookToSell.price,
      type: 'income',
      category: 'বই বিক্রি',
      description: `${bookToSell.name} বিক্রি করা হয়েছে`,
    };
    setTransactions(prev => [trans, ...prev]);
  };

  const deleteBook = (id: string) => {
    if (confirm('আপনি কি এই বইটি মুছে ফেলতে চান?')) {
      setBooks(prev => prev.filter(b => b.id !== id));
    }
  };

  return (
    <div className="space-y-4">
      {/* Search & Action */}
      <div className="flex space-x-2 sticky top-[72px] z-30 bg-slate-50 py-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="বই, লাইব্রেরি বা দাম দিয়ে খুঁজুন..."
            className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowAddForm(true)}
          className="bg-indigo-600 text-white p-3 rounded-xl shadow-lg active:scale-95 transition-transform"
        >
          <Plus size={24} />
        </button>
      </div>

      {/* Add Form Modal Overlay */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl p-6 shadow-2xl animate-in slide-in-from-bottom duration-300">
            <h2 className="text-xl font-bold mb-4">নতুন বই যোগ করুন</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">বইয়ের নাম</label>
                <input 
                  type="text" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newBook.name}
                  onChange={e => setNewBook({...newBook, name: e.target.value})}
                  placeholder="যেমন: গীতাঞ্জলি"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">লাইব্রেরি/প্রকাশনী</label>
                <input 
                  type="text" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newBook.library}
                  onChange={e => setNewBook({...newBook, library: e.target.value})}
                  placeholder="যেমন: বিশ্বসাহিত্য কেন্দ্র"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">মূল্য (৳)</label>
                <input 
                  type="number" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newBook.price}
                  onChange={e => setNewBook({...newBook, price: e.target.value})}
                  placeholder="0.00"
                />
              </div>
              <div className="flex space-x-3 pt-2">
                <button 
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 py-3 border border-slate-200 text-slate-600 rounded-lg font-bold"
                >
                  বাতিল
                </button>
                <button 
                  onClick={addBook}
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-lg font-bold"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Book List */}
      <div className="grid grid-cols-1 gap-4">
        {filteredBooks.length === 0 ? (
          <div className="text-center py-20 text-slate-400">
            <BookOpen size={48} className="mx-auto mb-2 opacity-20" />
            <p>কোনো বই পাওয়া যায়নি</p>
          </div>
        ) : (
          filteredBooks.map(book => (
            <div key={book.id} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between group">
              <div className="flex-1">
                <h4 className="font-bold text-slate-800 leading-tight">{book.name}</h4>
                <div className="flex items-center space-x-3 mt-1 text-slate-500 text-xs">
                  <div className="flex items-center">
                    <Library size={12} className="mr-1" />
                    <span>{book.library}</span>
                  </div>
                  <div className="flex items-center text-indigo-600 font-medium">
                    <Tag size={12} className="mr-1" />
                    <span>৳{book.price}</span>
                  </div>
                </div>
                <div className="mt-2 inline-block px-2 py-1 bg-slate-100 rounded text-[10px] font-bold text-slate-600">
                  বিক্রি: {book.salesCount} কপি
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => sellBook(book.id)}
                  className="p-3 bg-emerald-50 text-emerald-600 rounded-lg active:bg-emerald-600 active:text-white transition-colors"
                  title="Sell one copy"
                >
                  <ShoppingCart size={18} />
                </button>
                <button 
                  onClick={() => deleteBook(book.id)}
                  className="p-3 bg-rose-50 text-rose-500 rounded-lg active:bg-rose-500 active:text-white transition-colors"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// Simple reusable icons for the component
import { BookOpen } from 'lucide-react';
