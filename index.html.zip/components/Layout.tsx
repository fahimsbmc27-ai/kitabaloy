
import React from 'react';
import { LayoutDashboard, BookOpen, Wallet, Users, BarChart3 } from 'lucide-react';
import { TabType } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'dashboard' as TabType, label: 'হোম', icon: LayoutDashboard },
    { id: 'inventory' as TabType, label: 'বই', icon: BookOpen },
    { id: 'finance' as TabType, label: 'হিসাব', icon: Wallet },
    { id: 'customers' as TabType, label: 'ক্রেতা', icon: Users },
    { id: 'analytics' as TabType, label: 'রিপোর্ট', icon: BarChart3 },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-indigo-700 text-white p-4 shadow-lg">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold tracking-tight">কিতাবালয় <span className="text-indigo-200 text-sm font-normal">Kitabaloy</span></h1>
          <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center">
            <span className="text-sm font-medium">KB</span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 pb-24 overflow-y-auto px-4 py-6">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 safe-bottom shadow-[0_-4px_10px_rgba(0,0,0,0.05)] z-50">
        <div className="flex justify-around items-center h-16">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center justify-center w-full h-full transition-colors duration-200 ${
                  isActive ? 'text-indigo-700' : 'text-slate-400'
                }`}
              >
                <Icon size={22} className={isActive ? 'scale-110' : ''} />
                <span className="text-[10px] mt-1 font-medium">{tab.label}</span>
                {isActive && <div className="absolute bottom-1 w-1 h-1 bg-indigo-700 rounded-full" />}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
