
import React, { useState } from 'react';
import { UserPlus, Search, Phone, Mail, MapPin, Trash2 } from 'lucide-react';
import { Customer } from '../types';

interface CustomersProps {
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
}

export const Customers: React.FC<CustomersProps> = ({ customers, setCustomers }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [newCust, setNewCust] = useState({ name: '', phone: '', email: '', address: '' });

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.phone.includes(searchTerm)
  );

  const addCustomer = () => {
    if (!newCust.name || !newCust.phone) return;
    const customer: Customer = {
      id: Date.now().toString(),
      name: newCust.name,
      phone: newCust.phone,
      email: newCust.email || 'নাই',
      address: newCust.address || 'নাই',
      totalPurchase: 0,
    };
    setCustomers(prev => [customer, ...prev]);
    setNewCust({ name: '', phone: '', email: '', address: '' });
    setShowAddForm(false);
  };

  const deleteCustomer = (id: string) => {
    if (confirm('আপনি কি এই ক্রেতার তথ্য মুছে ফেলতে চান?')) {
      setCustomers(prev => prev.filter(c => c.id !== id));
    }
  };

  return (
    <div className="space-y-4">
      {/* Header with Search */}
      <div className="flex space-x-2 sticky top-[72px] z-30 bg-slate-50 py-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="ক্রেতার নাম বা ফোন..."
            className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowAddForm(true)}
          className="bg-indigo-600 text-white p-3 rounded-xl shadow-lg"
        >
          <UserPlus size={24} />
        </button>
      </div>

      {/* Customer List */}
      <div className="space-y-4">
        {filteredCustomers.length === 0 ? (
          <div className="text-center py-20 text-slate-400 font-medium">ক্রেতার তালিকা খালি</div>
        ) : (
          filteredCustomers.map(cust => (
            <div key={cust.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500"></div>
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h4 className="text-lg font-bold text-slate-800">{cust.name}</h4>
                  <div className="flex items-center text-slate-500 text-sm mt-1">
                    <Phone size={14} className="mr-2" />
                    <span>{cust.phone}</span>
                  </div>
                </div>
                <button onClick={() => deleteCustomer(cust.id)} className="text-rose-400 p-1">
                  <Trash2 size={18} />
                </button>
              </div>
              <div className="grid grid-cols-1 gap-2 border-t border-slate-50 pt-3 mt-3">
                <div className="flex items-center text-slate-500 text-xs">
                  <Mail size={12} className="mr-2" />
                  <span>{cust.email}</span>
                </div>
                <div className="flex items-center text-slate-500 text-xs">
                  <MapPin size={12} className="mr-2" />
                  <span>{cust.address}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Customer Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex items-end sm:items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl p-6 shadow-2xl animate-in slide-in-from-bottom duration-300">
            <h2 className="text-xl font-bold mb-4">নতুন ক্রেতা যোগ করুন</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">নাম</label>
                <input 
                  type="text" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newCust.name}
                  onChange={e => setNewCust({...newCust, name: e.target.value})}
                  placeholder="ক্রেতার নাম"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">ফোন নম্বর</label>
                <input 
                  type="tel" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newCust.phone}
                  onChange={e => setNewCust({...newCust, phone: e.target.value})}
                  placeholder="017xxxxxxxx"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">ইমেইল</label>
                <input 
                  type="email" 
                  className="w-full p-3 border border-slate-200 rounded-lg"
                  value={newCust.email}
                  onChange={e => setNewCust({...newCust, email: e.target.value})}
                  placeholder="example@gmail.com"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600 block mb-1">ঠিকানা</label>
                <textarea 
                  className="w-full p-3 border border-slate-200 rounded-lg h-20"
                  value={newCust.address}
                  onChange={e => setNewCust({...newCust, address: e.target.value})}
                  placeholder="ক্রেতার পূর্ণ ঠিকানা"
                />
              </div>
              <div className="flex space-x-3 pt-2">
                <button onClick={() => setShowAddForm(false)} className="flex-1 py-3 border border-slate-200 text-slate-600 rounded-lg font-bold">বাতিল</button>
                <button onClick={addCustomer} className="flex-1 py-3 bg-indigo-600 text-white rounded-lg font-bold">সংরক্ষণ করুন</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
