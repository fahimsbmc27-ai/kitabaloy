
import React, { useMemo } from 'react';
import { TrendingUp, TrendingDown, BookCheck, Users2 } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Book, Transaction, Customer } from '../types';

interface DashboardProps {
  books: Book[];
  transactions: Transaction[];
  customers: Customer[];
}

export const Dashboard: React.FC<DashboardProps> = ({ books, transactions, customers }) => {
  const stats = useMemo(() => {
    const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
    const topBook = [...books].sort((a, b) => b.salesCount - a.salesCount)[0];
    
    return {
      balance: totalIncome - totalExpense,
      income: totalIncome,
      expense: totalExpense,
      totalBooks: books.length,
      totalCustomers: customers.length,
      topBookName: topBook ? topBook.name : 'নেই'
    };
  }, [books, transactions, customers]);

  const chartData = useMemo(() => {
    // Last 7 days chart data
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toLocaleDateString('bn-BD', { weekday: 'short' });
    });

    return days.map(day => ({
      name: day,
      income: Math.floor(Math.random() * 5000), // Real data would be aggregated here
      expense: Math.floor(Math.random() * 2000),
    }));
  }, [transactions]);

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-2xl p-6 text-white shadow-xl">
        <p className="text-indigo-100 text-sm">বর্তমান ব্যালেন্স</p>
        <h2 className="text-3xl font-bold mt-1">৳ {stats.balance.toLocaleString()}</h2>
        <div className="flex mt-6 space-x-4">
          <div className="flex-1 bg-white/10 rounded-xl p-3 backdrop-blur-sm">
            <div className="flex items-center text-emerald-300 space-x-1">
              <TrendingUp size={14} />
              <span className="text-[10px] font-bold uppercase">আয়</span>
            </div>
            <p className="text-lg font-bold">৳ {stats.income.toLocaleString()}</p>
          </div>
          <div className="flex-1 bg-white/10 rounded-xl p-3 backdrop-blur-sm">
            <div className="flex items-center text-rose-300 space-x-1">
              <TrendingDown size={14} />
              <span className="text-[10px] font-bold uppercase">ব্যয়</span>
            </div>
            <p className="text-lg font-bold">৳ {stats.expense.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Mini Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-3">
          <div className="p-2 bg-amber-100 text-amber-600 rounded-lg">
            <BookCheck size={20} />
          </div>
          <div>
            <p className="text-xs text-slate-500">মোট বই</p>
            <p className="font-bold">{stats.totalBooks}</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-3">
          <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
            <Users2 size={20} />
          </div>
          <div>
            <p className="text-xs text-slate-500">মোট ক্রেতা</p>
            <p className="font-bold">{stats.totalCustomers}</p>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="text-sm font-bold mb-4 text-slate-600">সাপ্তাহিক লেনদেন চিত্র</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b'}} />
              <Tooltip />
              <Area type="monotone" dataKey="income" stroke="#10b981" fillOpacity={1} fill="url(#colorIncome)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top Selling */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="text-sm font-bold mb-3 text-slate-600">সবচেয়ে বেশি বিক্রিত বই</h3>
        <div className="flex items-center justify-between p-3 bg-indigo-50 rounded-xl border border-indigo-100">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-600 text-white rounded-lg flex items-center justify-center font-bold">
              #১
            </div>
            <div>
              <p className="font-bold text-indigo-900">{stats.topBookName}</p>
              <p className="text-xs text-indigo-600">সেরা বিক্রিত</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-bold text-indigo-700">{books.find(b => b.name === stats.topBookName)?.salesCount || 0} কপি</p>
          </div>
        </div>
      </div>
    </div>
  );
};
