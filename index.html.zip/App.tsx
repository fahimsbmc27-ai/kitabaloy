
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { Finance } from './components/Finance';
import { Customers } from './components/Customers';
import { Analytics } from './components/Analytics';
import { Book, Transaction, Customer, TabType } from './types';

const STORAGE_KEY = 'kitabaloy_data_v1';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  
  // App State
  const [books, setBooks] = useState<Book[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);

  // Load data
  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      const parsed = JSON.parse(savedData);
      setBooks(parsed.books || []);
      setTransactions(parsed.transactions || []);
      setCustomers(parsed.customers || []);
    } else {
      // Mock initial data if empty
      setBooks([
        { id: '1', name: 'হিমু সমগ্র', library: 'অন্যপ্রকাশ', price: 450, salesCount: 15, addedAt: Date.now() },
        { id: '2', name: 'পদ্মা নদীর মাঝি', library: 'স্টুডেন্ট ওয়েজ', price: 200, salesCount: 8, addedAt: Date.now() },
      ]);
    }
  }, []);

  // Save data whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ books, transactions, customers }));
  }, [books, transactions, customers]);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard books={books} transactions={transactions} customers={customers} />;
      case 'inventory':
        return <Inventory books={books} setBooks={setBooks} transactions={transactions} setTransactions={setTransactions} />;
      case 'finance':
        return <Finance transactions={transactions} setTransactions={setTransactions} />;
      case 'customers':
        return <Customers customers={customers} setCustomers={setCustomers} />;
      case 'analytics':
        return <Analytics books={books} transactions={transactions} />;
      default:
        return <Dashboard books={books} transactions={transactions} customers={customers} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
    </Layout>
  );
};

export default App;
